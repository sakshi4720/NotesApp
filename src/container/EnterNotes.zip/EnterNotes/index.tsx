import React, { useEffect, useState } from "react";
import { Button, SafeAreaView, TextInput, Text, View, FlatList } from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import styles from './styles';
import { RootStackParamList } from "../../services/RootNavigator";
import { RouteProp, useRoute } from "@react-navigation/native";



const EnterNotes = () => {

    // const route = useRoute<RouteProp<RootStackParamList, "EnterNotes">>()

    const [txtInpValue, setTxtInpValue] = useState<string>('')

    const [newNote, setNewNote] = useState<Array<string>>([])

    interface Note {
        //  id: number,
        notes: string
    }

    const Notes: Note[] = [
        {
            //id: 0,
            notes: txtInpValue
        }
    ]

    useEffect(() => {
        () => {
            setNewNote(newNote);
        }
    })


    const renderNotesData = ({ item }: { item: Note }) => {
        return (
            <Text style={styles.label}
                numberOfLines={1}>{item.notes}</Text>
        )
    }

    const onChangeText = (text: string) => {
        setTxtInpValue(text)
    }

    const onPressAddNoteBtn = () => {

        setNewNote(Notes => [...Notes, newNote]);
      
    //    if (newNote !== null) setNewNote([...Notes,newNote])
    }

    return (
        <SafeAreaView style={styles.rootMainContainer}>
            <Text style={styles.label}>Enter Notes </Text>

            <FlatList data={Notes}
                renderItem={renderNotesData} />

            <TextInput style={styles.txtInputContainer}
                placeholder={'Enter your text here...'}
                multiline={false}
                value={txtInpValue}
                onChangeText={text => onChangeText(text)} />

            <Button
                onPress={() => onPressAddNoteBtn()}
                title="Add Note"
                color="#841584"
            />

        </SafeAreaView>
    )
}

export default EnterNotes;